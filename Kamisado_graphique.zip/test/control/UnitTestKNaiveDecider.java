package control;

public class UnitTestKNaiveDecider {
}
