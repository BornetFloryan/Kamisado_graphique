package view;

public class K_GameRules {
}
