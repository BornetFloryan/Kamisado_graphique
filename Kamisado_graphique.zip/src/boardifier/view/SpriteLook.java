package boardifier.view;

import boardifier.model.GameElement;

public abstract class SpriteLook extends ElementLook {

    public SpriteLook(GameElement element) {
        super(element);
    }

}
